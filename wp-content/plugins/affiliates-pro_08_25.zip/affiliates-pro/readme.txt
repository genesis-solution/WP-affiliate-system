=== Affiliates Pro ===
Tags: affiliate, affiliates, affiliate marketing, referral, growth marketing, ads, AddToAny, AddThis, advertising, affiliate plugin, affiliate tool, contact form, contact form 7, downloads, e-commerce, Ecwid, Events Manager, Jigoshop, lead, link, marketing, money, partner, Pay per Click, PayPal, PPC, referral links, referrer, sales, shopping cart, track, transaction, WooCommerce
Requires at least: 6.0
Tested up to: 6.2
Requires PHP: 7.2
Stable tag: 4.19.0
License: For files where GPLv3 applies or the license obtained via itthinx.com where the GPLv3 does not apply.

The Affiliates Pro system provides advanced tools to manage an affiliate program.

== Description ==
